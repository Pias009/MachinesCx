import React from 'react';

interface HomeViewProps {
  onOpenLab: () => void;
  onOpenContact: () => void;
  platesCount: number;
}

export const HomeView: React.FC<HomeViewProps> = ({ onOpenLab, onOpenContact, platesCount }) => {
  return (
    <div className="relative z-10 pt-28 md:pt-36 pb-16 overflow-hidden">
      {/* Aircenter Hero Section from Video */}
      <section className="relative min-h-[90vh] flex flex-col justify-between px-6 md:px-12 max-w-[1700px] mx-auto select-none pt-12 md:pt-16">
        
        {/* Mobile Title fallback (Desktop title is in Navbar) */}
        <div className="lg:hidden text-center text-[10px] font-display font-semibold tracking-[0.2em] uppercase text-[#101114] mb-8">
          THE ARCHITECTURE OF NEW SUCCESS
        </div>

        {/* Giant Backdrop Typography A I R */}
        <div className="my-auto grid grid-cols-3 items-center w-full pointer-events-none z-0">
          <div className="text-[26vw] lg:text-[22vw] font-display font-bold leading-none tracking-tighter text-[#101114] text-left select-none animate-fade-in">
            A
          </div>
          <div className="text-[26vw] lg:text-[22vw] font-display font-bold leading-none tracking-tighter text-[#101114] text-center select-none animate-fade-in">
            I
          </div>
          <div className="relative flex items-center justify-between w-full">
            <div className="hidden md:block absolute -left-20 lg:-left-32 z-20 text-[10px] lg:text-xs font-mono tracking-[0.25em] uppercase text-[#7c828c] leading-loose text-center pointer-events-auto bg-white/40 backdrop-blur-xs p-3 rounded border border-black/5">
              CLASS 2.0<br/>
              PREMIUM BUSINESS<br/>
              CENTER
            </div>
            <div className="text-[26vw] lg:text-[22vw] font-display font-bold leading-none tracking-tighter text-[#101114] ml-auto text-right select-none animate-fade-in">
              R
            </div>
          </div>
        </div>

        {/* Interactive Lab & Cookie Banner bottom row */}
        <div className="relative z-20 flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-[#101114]/10 mt-8 pointer-events-auto">
          
          <div className="flex items-center gap-4">
            <button 
              onClick={onOpenLab}
              className="px-6 py-3 bg-[#101114] text-white text-xs font-mono tracking-widest uppercase hover:bg-[#33353b] transition-all cursor-pointer shadow-sm rounded-full font-bold flex items-center gap-2"
            >
              <span>⚙</span> Systems Lab ({platesCount} Plates)
            </button>
            <button 
              onClick={onOpenContact}
              className="px-6 py-3 border border-[#101114]/20 text-[#101114] text-xs font-mono tracking-widest uppercase hover:border-[#101114] hover:bg-[#101114] hover:text-white transition-all cursor-pointer rounded-full"
            >
              Inquire Space
            </button>
          </div>

          {/* Aircenter Cookie Banner clone */}
          <div className="flex items-center gap-3 px-4 py-2 bg-[#f0f0ee] border border-[#101114]/15 rounded-full font-mono text-[10px] uppercase tracking-wider text-[#101114] shadow-xs">
            <span className="text-[#7c828c]">THIS WEBSITE USES COOKIES</span>
            <button className="px-3 py-1 bg-white border border-[#101114]/20 rounded font-bold hover:bg-[#101114] hover:text-white transition-all cursor-pointer">
              ACCEPT
            </button>
          </div>

          <div className="flex items-center gap-3 text-[10px] font-mono text-[#7c828c] uppercase tracking-widest">
            <div className="w-0.5 h-6 bg-gradient-to-b from-[#101114] to-transparent animate-pulse" />
            <span>SCROLL KINETIC TOWER</span>
          </div>

        </div>
      </section>

      {/* Infinite Kinetic Marquee (Signature Studio Feature) */}
      <div className="w-full py-8 my-16 bg-[#16181d] text-white overflow-hidden select-none border-y border-[#16181d]">
        <div className="flex whitespace-nowrap animate-[marquee_25s_linear_infinite] gap-12 font-display text-2xl md:text-4xl font-bold tracking-tight uppercase opacity-90">
          <span>REALTIME KINETIC ARCHITECTURE</span>
          <span className="text-[#7c828c] font-serif italic font-normal">●</span>
          <span>PROCEDURAL WEBGL SYNTHESIS</span>
          <span className="text-[#7c828c] font-serif italic font-normal">●</span>
          <span>INERTIAL LENIS MOMENTUM</span>
          <span className="text-[#7c828c] font-serif italic font-normal">●</span>
          <span>REALTIME KINETIC ARCHITECTURE</span>
          <span className="text-[#7c828c] font-serif italic font-normal">●</span>
          <span>PROCEDURAL WEBGL SYNTHESIS</span>
          <span className="text-[#7c828c] font-serif italic font-normal">●</span>
          <span>INERTIAL LENIS MOMENTUM</span>
          <span className="text-[#7c828c] font-serif italic font-normal">●</span>
        </div>
      </div>

      {/* Sticky Pinning Layout Rhythm (Aircenter Style) */}
      <section className="py-16 md:py-32 px-6 md:px-12 max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-5 lg:sticky lg:top-36 self-start space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-6 h-[1px] bg-[#16181d]" />
            <span className="text-[11px] font-mono uppercase tracking-[0.28em] text-[#16181d] font-bold">01 — Core Mechanics</span>
          </div>
          <h2 className="text-4xl sm:text-6xl font-bold tracking-tight leading-[0.95] text-[#16181d]">
            Mathematical <span className="text-[#7c828c] italic font-normal font-serif">oscillation</span> in three dimensions.
          </h2>
          <p className="text-[#7c828c] text-base sm:text-lg leading-relaxed pt-4">
            As you scroll down, camera trajectory descends vertically along the tower while recalculating view matrix projections. The architecture responds directly to viewport momentum.
          </p>
          <div className="pt-4">
            <button
              onClick={onOpenLab}
              className="px-6 py-3 bg-[#ececea] text-xs font-mono uppercase tracking-widest text-[#16181d] hover:bg-[#16181d] hover:text-white transition-all cursor-pointer font-bold"
            >
              Open Interactive Lab Core →
            </button>
          </div>
        </div>

        {/* Scrolling Right Side Cards */}
        <div className="lg:col-span-7 space-y-12 lg:pl-12">
          <div className="bg-[#fafafa]/80 backdrop-blur-md p-8 md:p-12 border border-[#16181d]/10 transition-all hover:border-[#16181d]/40 shadow-sm">
            <span className="font-mono text-xs text-[#7c828c] uppercase tracking-widest block mb-4">/ Specification 01</span>
            <h3 className="text-2xl md:text-4xl font-bold font-display text-[#16181d]">Calibrated Angular Twist</h3>
            <p className="text-[#7c828c] mt-4 leading-relaxed text-base">
              Each horizontal plate rotates exactly 9.2° relative to its predecessor. Across 120 stacked units, this completes precisely 3 full 360° revolutions before terminating at crown altitude.
            </p>
          </div>

          <div className="bg-[#fafafa]/80 backdrop-blur-md p-8 md:p-12 border border-[#16181d]/10 transition-all hover:border-[#16181d]/40 shadow-sm">
            <span className="font-mono text-xs text-[#7c828c] uppercase tracking-widest block mb-4">/ Specification 02</span>
            <h3 className="text-2xl md:text-4xl font-bold font-display text-[#16181d]">PCF Soft Shadow Mapping</h3>
            <p className="text-[#7c828c] mt-4 leading-relaxed text-base">
              Percentage-closer filtering shadow projections mapped at 2048×2048 resolution prevent harsh polygonal banding, letting pure white architectural volumes read clearly against near-white voids.
            </p>
          </div>

          <div className="bg-[#fafafa]/80 backdrop-blur-md p-8 md:p-12 border border-[#16181d]/10 transition-all hover:border-[#16181d]/40 shadow-sm">
            <span className="font-mono text-xs text-[#7c828c] uppercase tracking-widest block mb-4">/ Specification 03</span>
            <h3 className="text-2xl md:text-4xl font-bold font-display text-[#16181d]">GPU Procedural Morphing</h3>
            <p className="text-[#7c828c] mt-4 leading-relaxed text-base">
              Switching presets between Tower, Helix, Monolith, and Lattice executes instantaneously without vertex shader compilation lag or dropped frame buffers.
            </p>
          </div>
        </div>
      </section>

      {/* Band 2: Light */}
      <section className="py-24 md:py-36 px-6 md:px-12 border-t border-[#16181d]/10 max-w-[1400px] mx-auto mt-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-6 h-[1px] bg-[#7c828c]" />
          <span className="text-[11px] font-mono uppercase tracking-[0.28em] text-[#7c828c]">02 — Atmosphere</span>
        </div>
        
        <h2 className="text-3xl sm:text-5xl lg:text-[72px] font-bold tracking-tight max-w-[800px] leading-[0.96] text-[#16181d]">
          Pristine <span className="text-[#7c828c] italic font-normal font-serif">monochromatic</span> light balance.
        </h2>
        
        <p className="mt-6 max-w-[580px] text-[#7c828c] text-base sm:text-lg leading-relaxed">
          Inspired by Swiss architectural photography, environmental illumination relies purely on diffuse hemispheric sky radiance paired with a singular high-angle solar directional beam.
        </p>

        <div className="mt-12 flex gap-4">
          <button 
            onClick={onOpenLab}
            className="px-8 py-4 bg-[#16181d] text-white text-xs font-mono uppercase tracking-widest hover:bg-transparent hover:text-[#16181d] border border-[#16181d] transition-all cursor-pointer"
          >
            Enter Systems Lab →
          </button>
        </div>
      </section>

      {/* Footer Bar */}
      <footer className="mt-20 px-6 md:px-12 py-8 border-t border-[#16181d]/10 flex flex-col sm:flex-row justify-between items-start sm:items-end gap-8 max-w-[1400px] mx-auto z-10">
        <div className="flex items-center gap-3 text-[10px] font-mono text-[#7c828c] uppercase tracking-widest">
          <div className="w-0.5 h-8 bg-gradient-to-b from-[#16181d] to-transparent" />
          Aircenter Kinetic Clone · VECTROL
        </div>
        
        <div className="flex flex-wrap gap-12 sm:gap-16">
          <div className="text-[10px] font-mono text-[#7c828c] leading-relaxed">
            <span className="block font-bold text-[#16181d] mb-1 uppercase tracking-tight">Transmission</span>
            hello@vectrol.example<br/>
            +1 (000) 555 0142
          </div>
          <div className="text-[10px] font-mono text-[#7c828c] leading-relaxed sm:text-right">
            <span className="block font-bold text-[#16181d] mb-1 uppercase tracking-tight">System Status</span>
            REV 4.2 // LENIS ACTIVE<br/>
            © 2026 VECTROL
          </div>
        </div>
      </footer>
    </div>
  );
};
