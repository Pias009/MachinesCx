import React from 'react';
import { ViewMode } from '../types';

interface NavbarProps {
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  autoRotate: boolean;
  onToggleRotate: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onSelectView,
  autoRotate,
  onToggleRotate,
}) => {
  return (
    <nav className="fixed top-0 left-0 right-0 flex justify-between items-center px-6 md:px-12 py-6 md:py-8 z-30 pointer-events-auto">
      <div className="flex items-center gap-3">
        <div 
          className="text-lg font-display font-black tracking-tighter uppercase cursor-pointer select-none text-[#101114] flex items-center gap-2"
          onClick={() => onSelectView('home')}
        >
          <span className="w-6 h-6 rounded-full border border-[#101114] flex items-center justify-center text-[10px] font-mono font-bold">↗</span>
          AIR
        </div>
      </div>

      {/* Aircenter Center Title from Video */}
      <div className="hidden lg:block absolute left-1/2 -translate-x-1/2 text-xs font-display font-semibold tracking-[0.25em] uppercase text-[#101114] select-none">
        THE ARCHITECTURE OF NEW SUCCESS
      </div>

      <div className="flex items-center gap-4 md:gap-8 text-[11px] font-mono uppercase tracking-widest text-[#7c828c]">
        <button
          onClick={() => onSelectView('tech')}
          className={`cursor-pointer transition-colors pb-1 flex items-center gap-1.5 ${
            currentView === 'tech'
              ? 'text-[#16181d] font-bold border-b border-[#16181d]'
              : 'hover:text-[#16181d]'
          }`}
        >
          Systems <span className="text-[9px] px-1.5 py-0.5 bg-[#16181d]/10 text-[#16181d] rounded font-bold">LAB</span>
        </button>

        <button
          onClick={onToggleRotate}
          className="hidden sm:flex items-center gap-1.5 text-[9px] tracking-wider border border-[#16181d]/20 px-2.5 py-1 rounded hover:border-[#16181d] text-[#16181d] transition-all cursor-pointer bg-white/50 backdrop-blur-sm"
          title={autoRotate ? "Pause kinetic motor" : "Start kinetic motor"}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${autoRotate ? 'bg-emerald-600 animate-pulse' : 'bg-[#7c828c]'}`} />
          {autoRotate ? 'MOTOR ON' : 'PAUSED'}
        </button>

        {/* Aircenter signature black pill button */}
        <button
          onClick={() => onSelectView('contact')}
          className="px-5 py-2.5 bg-[#101114] text-white rounded-full text-[10px] font-mono font-bold tracking-wider uppercase hover:bg-[#33353b] transition-all cursor-pointer shadow-md hover:scale-105"
        >
          CHOOSE AN OFFICE
        </button>
      </div>
    </nav>
  );
};

